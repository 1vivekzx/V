# no code shrinking is used (minifyEnabled false)
